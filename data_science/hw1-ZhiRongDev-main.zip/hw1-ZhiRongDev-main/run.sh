rm -rf ./output
rm -rf ./hw1/eval

### correct test
Rscript hw1_111753151.R  --output ./output/test1/output1.csv --input ./example/input1.csv
Rscript hw1_111753151.R  --output ./output/test1/output2.csv --input ./example/input2.csv
Rscript hw1_111753151.R  --output ./output/test1/output3.csv --input ./example/input3.csv

Rscript hw1_111753151.R --input ./example/input1.csv --output ./output/test2/output1.csv
Rscript hw1_111753151.R --input ./example/input2.csv --output ./output/test2/output2.csv
Rscript hw1_111753151.R --input ./example/input3.csv --output ./output/test2/output3.csv

Rscript hw1_111753151.R  --output output/test3/output1.csv --input ./example/input1.csv
Rscript hw1_111753151.R  --output output/test3/output2.csv --input ./example/input2.csv
Rscript hw1_111753151.R  --output output/test3/output3.csv --input ./example/input3.csv

Rscript hw1_111753151.R --input hw1/data/test.1.csv --output hw1/eval/test1/hw1_001.csv
Rscript hw1_111753151.R --output hw1/eval/test2/hw1_002.csv --input hw1/data/test.2.csv

### Error test
# Rscript hw1_111753151.R  --output ./output/test1/output1.csv --input ./kpsd/asdsad
# Rscript hw1_111753151.R  --output ./output/test1/output1.csv --input 
# Rscript hw1_111753151.R  --output  --input ./kpsd/asdsad
# Rscript hw1_111753151.R  ./output/test1/output1.csv  --input hw1/data/test.2.csv --output